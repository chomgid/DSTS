# Doubly Structured Data Synthesis for Time-series Energy Use Data

Still under development!  **Not ready for use**

This repository contains the official Python package implementation of the paper "Doubly Structured Data Synthesis for Time-series Energy Use Data"

## Installation


## How to use

